﻿namespace OlympicGamesKennedy.Models
{
    public class OlympicTeam
    {
        public string OlympicTeamID { get; set; } = string.Empty; 
        public string Country { get; set; } = string.Empty; 
        public Category Category { get; set; } = null!; 
        public Game Game { get; set; } = null!; 
        public string FlagImage { get; set; } = string.Empty;

    }
}
