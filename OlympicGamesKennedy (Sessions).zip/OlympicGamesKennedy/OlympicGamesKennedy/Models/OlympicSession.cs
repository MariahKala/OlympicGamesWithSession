﻿namespace OlympicGamesKennedy.Models
{
    public class OlympicSession
    {
        private const string OlympicTeamsKey = "myolympicteams";
        private const string OlympicCountKey = "olympicteamcount";
        private const string GamKey = "gam";
        private const string CategKey = "categ";

        private ISession session { get; set; }
        public OlympicSession(ISession session) => this.session = session;

        public void SetMyTeams(List<OlympicTeam> olympicteams)
        {
            session.SetObject(OlympicTeamsKey, olympicteams);
            session.SetInt32(OlympicCountKey, olympicteams.Count);
        }
        public List<OlympicTeam> GetMyTeams() =>
            session.GetObject<List<OlympicTeam>>(OlympicTeamsKey) ?? new List<OlympicTeam>();
        public int? GetMyTeamCount() => session.GetInt32(OlympicCountKey);
        public void SetActiveGam(string activeGam) =>
            session.SetString(GamKey, activeGam);
        public string GetActiveGam() =>
            session.GetString(CategKey) ?? string.Empty;
        public void SetActiveCateg(string activeCateg) =>
            session.SetString(CategKey, activeCateg);
        public string GetActiveCateg() =>
            session.GetString(CategKey) ?? string.Empty;

        public void RemoveMyTeams()
        {
            session.Remove(OlympicTeamsKey);
            session.Remove(OlympicCountKey);
        }
    }
}