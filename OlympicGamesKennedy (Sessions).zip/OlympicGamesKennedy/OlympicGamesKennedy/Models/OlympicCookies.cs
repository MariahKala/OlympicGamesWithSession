﻿

namespace OlympicGamesKennedy.Models
{
    public class OlympicCookies
    {
        private const string OlympicTeamsKey = "myolympicteams";
        private const string Delimiter = "-";

        private IRequestCookieCollection requestCookies { get; set; } = null!;
        private IResponseCookies responseCookies { get; set; } = null!;

        public OlympicCookies(IRequestCookieCollection cookies)
        {
            requestCookies = cookies;
        }
        public OlympicCookies(IResponseCookies cookies)
        {
            responseCookies = cookies;
        }

        public void SetMyTeamIds(List<OlympicTeam> myolympicteams)
        {
            List<string> ids = myolympicteams.Select(t => t.OlympicTeamID).ToList();
            string idsString = String.Join(Delimiter, ids);
            CookieOptions options = new CookieOptions
            {
                Expires = DateTime.Now.AddDays(30)
            };
            RemoveMyTeamIds();     // Have to get rid of old cookies first with this line.
            responseCookies.Append(OlympicTeamsKey, idsString, options);
        }

        public string[] GetMyTeamIds()
        {
            string cookie = requestCookies[OlympicTeamsKey] ?? String.Empty;
            if (string.IsNullOrEmpty(cookie))
                return Array.Empty<string>();   // I don't undertsnad this as much but it is an empty string.
            else
                return cookie.Split(Delimiter);
        }

        public void RemoveMyTeamIds()
        {
            responseCookies.Delete(OlympicTeamsKey);
        }
    }
}
