﻿namespace OlympicGamesKennedy.Models
{
    public class OlympicTeamViewModel
    {
     
            public string ActiveGam { get; set; } = "all";
            public string ActiveCateg { get; set; } = "all";

            public OlympicTeam OlympicTeam { get; set; } = new OlympicTeam();

            public List<OlympicTeam> OlympicTeams { get; set; } = new List<OlympicTeam>();
            public List<Game> Games { get; set; } =
                new List<Game>();
            public List<Category> Categories { get; set; } =
                new List<Category>();

            // These emthods help the view know what the active link is in the project.
            public string CheckActiveGam(string c) =>
                c.ToLower() == ActiveGam.ToLower() ? "active" : "";

            public string CheckActiveCateg(string d) =>
                d.ToLower() == ActiveCateg.ToLower() ? "active" : "";
        }

    }

