using Microsoft.EntityFrameworkCore;
using OlympicGamesKennedy.Models;

var builder = WebApplication.CreateBuilder(args);

//Builders for session state. These must be called before AddControllersWithViews()
builder.Services.AddMemoryCache();
builder.Services.AddSession(options =>
{
    // change idle timeout to 5 minutes - default is 20 minutes
    options.IdleTimeout = TimeSpan.FromSeconds(60 * 5);
    options.Cookie.HttpOnly = false;     // default is true
    options.Cookie.IsEssential = true;   // default is false
});


// Add services to the container.
builder.Services.AddControllersWithViews();

// Add EF Core DI for OlympicTeamContext
builder.Services.AddDbContext<OlympicTeamContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString(
            "OlympicTeamContext")));


var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

//app.UseSession must be called before routes are mapped.
app.UseSession();

app.UseAuthorization();

app.MapControllerRoute(
    name: "custom",
    pattern: "{controller}/{action}/gam-{activeGam}/categ-{activeCateg}");

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
