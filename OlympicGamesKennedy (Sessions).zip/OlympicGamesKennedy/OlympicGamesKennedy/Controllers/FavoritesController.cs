﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OlympicGamesKennedy.Models;

namespace OlympicGamesKennedy.Controllers
{
    public class FavoritesController : Controller
    {
        private OlympicTeamContext context;
        public FavoritesController(OlympicTeamContext ctx) => context = ctx;

        [HttpGet]
        public ViewResult Index()
        {
            // get favorite teams and current game and category
            // from session, pass to view in view model
            var session = new OlympicSession(HttpContext.Session);
            var model = new OlympicTeamViewModel
            {
                ActiveGam = session.GetActiveGam(),
                ActiveCateg = session.GetActiveCateg(),
                OlympicTeams = session.GetMyTeams()
            };

            return View(model);
        }

        [HttpPost]
        public RedirectToActionResult Add(OlympicTeam olympicteam)
        {
            //Gotta get the full Olympic Team data from our database first
            olympicteam = context.OlympicTeams
                 .Include(t => t.Game)
                 .Include(t => t.Category)
                 .Where(t => t.OlympicTeamID == olympicteam.OlympicTeamID)
                 .FirstOrDefault() ?? new OlympicTeam();

            // This adds the olympic Team chosen to session
            var session = new OlympicSession(HttpContext.Session);
            var olympicteams = session.GetMyTeams();
            olympicteams.Add(olympicteam);
            session.SetMyTeams(olympicteams);

            // This will set the Add to Fav message
            TempData["message"] = $"{olympicteam.Country} added to your favorites";

            // Then return page to Home page
            return RedirectToAction("Index", "Home",
                new
                {
                    ActiveGam = session.GetActiveGam(),
                    ActiveCateg = session.GetActiveCateg()
                });
        }

        [HttpPost]
        public RedirectToActionResult Delete()
        {
            //Delete favorite teams from session
            var session = new OlympicSession(HttpContext.Session);
            var cookies = new OlympicCookies(Response.Cookies);
            
            session.RemoveMyTeams();
            cookies.RemoveMyTeamIds();

            //Assign delete message
            TempData["message"] = "Favorite teams cleared";

            //Back to Home page
            return RedirectToAction("Index", "Home",
                new
                {
                    ActiveConf = session.GetActiveGam(),
                    ActiveDiv = session.GetActiveCateg()
                });
        }
    }
}