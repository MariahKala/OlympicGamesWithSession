﻿using Microsoft.AspNetCore.Mvc;
using OlympicGamesKennedy.Models;
using Microsoft.EntityFrameworkCore;



public class HomeController : Controller
{
    private OlympicTeamContext context;

    public HomeController(OlympicTeamContext ctx)
    {
        context = ctx;
    }
    public ViewResult Index(OlympicTeamViewModel model)
    {
        //This stores active Games and Categories in the session.
        var session = new OlympicSession(HttpContext.Session);
        session.SetActiveGam(model.ActiveGam);
        session.SetActiveCateg(model.ActiveCateg);

        //If there is no count info then it will use cookie
        // Tehn resote favorite teams in the session.
        int? count = session.GetMyTeamCount();
        if (!count.HasValue)
        {
            var cookies = new OlympicCookies(Request.Cookies);
            string[] ids = cookies.GetMyTeamIds();

            if (ids.Length > 0)
            {
                var myolympicteams = context.OlympicTeams
                    .Include(t => t.Game)
                    .Include(t => t.Category)
                    .Where(t => ids.Contains(t.OlympicTeamID))
                    .ToList();
                session.SetMyTeams(myolympicteams);
            }
        }
        //These two lines get games and categories from the database
        model.Games = context.Games.ToList();
        model.Categories = context.Categories.ToList();

        //Then gets  olympic teams from database and filters.
        IQueryable<OlympicTeam> query = context.OlympicTeams.OrderBy(t => t.Country);
        if (model.ActiveGam != "all")
            query = query.Where(t =>
                t.Game.GameID.ToLower() ==
                     model.ActiveGam.ToLower());
        if (model.ActiveCateg != "all")
            query = query.Where(t =>
                t.Category.CategoryID.ToLower() ==
                     model.ActiveCateg.ToLower());
        model.OlympicTeams = query.ToList();
        return View(model);

    }
    public IActionResult Details(string id)
    {
        var session = new OlympicSession(HttpContext.Session);
        var model = new OlympicTeamViewModel
        {
            OlympicTeam = context.OlympicTeams
                .Include(t => t.Game)
                .Include(t => t.Category)
                .FirstOrDefault(t => t.OlympicTeamID == id) ?? new OlympicTeam(),
            ActiveCateg = session.GetActiveCateg(),
            ActiveGam = session.GetActiveGam()
        };
        return View(model);
    }
}

